# Changelog

## 0.4.7

*   Update Alloy Operator to 0.5.7, Beyla to 1.16.6, kube-state-metrics to 7.3.0, and Node Exporter to 4.55.0 (@petewall)

## 0.4.6

*   Update Alloy Operator to 0.5.5 and Beyla to 1.16.5 (@petewall)

## 0.4.5

*   Update Alloy Operator to 0.5.3, Beyla to 1.16.0, kube-state-metrics to 7.2.2, Node Exporter to 4.53.1, and Windows Exporter to 0.12.6 (@petewall)

## 0.4.4

*   Update Alloy Operator to 0.3.15 and Beyla Helm chart to 1.10.2 (@petewall)

## 0.4.3

*   Update Alloy Operator to 0.3.14 (@petewall)

## 0.4.2

*   Add `/sys/fs/cgroup` mount, which enables Beyla's visibility to all sockets created (@petewall)

## 0.4.1

*   Enabled clustering by default (@petewall)
*   Update kube-state-metrics and Node Exporter (@petewall)

## 0.4.0

*   Removed the "additionalComponents" chart in favor on a single chart (@petewall)
*   Added beyla-k8s-cache as additional component (@skl)
*   Update Alloy Operator to 0.3.13 (@skl)

## 0.3.1

*   Change Fleet Management polling interval to 30s (@petewall)
*   Update Alloy Operator and Node Exporter (@petewall)
*   Update Node Exporter and kube-state-metrics (@petewall)

## 0.3.0

*   Add uninstallation hook to ensure clean removal of Alloy resources (@petewall)

## 0.2.2

*   Update Alloy Operator to 0.3.9 (@petewall)
*   Update kube-state-metrics to 6.3.0 (@petewall)
*   Update Node Exporter to 4.47.3 (@petewall)
*   Update Windows Exporter to 0.12.1 (@petewall)
*   Remote Config to allow TLS and urlFrom settings (@petewall)

## 0.2.1

*   Update Alloy Operator to 0.3.8 (@petewall)
*   Update kube-state-metrics to 6.1.4 (@petewall)

## 0.2.0

*   Set hostNetwork to true and dnsPolicy to ClusterFirstWithHostNet for Alloy DaemonSet to enable Beyla to work with Asserts (@thampiotr)

## 0.1.1

*   Update Alloy Operator to 0.3.6 (@petewall)
*   Update Kepler to 0.6.1 (@petewall)

## 0.1.0

*   First release of the grafana-cloud-onboarding chart.
