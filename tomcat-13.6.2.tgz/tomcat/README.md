<!--- app-name: Apache Tomcat -->

# Bitnami Secure Images Helm chart for Apache Tomcat

Apache Tomcat is an open-source web server designed to host and run Java-based web applications. It is a lightweight server with a good performance for applications running in production environments.

[Overview of Apache Tomcat](http://tomcat.apache.org/)

Trademarks: This software listing is packaged by Bitnami. The respective trademarks mentioned in the offering are owned by the respective companies, and use of them does not imply any affiliation or endorsement.

## TL;DR

```console
helm install my-release oci://MY-OCI-REGISTRY/tomcat
```

## Why use Bitnami Secure Images?

Those are hardened, minimal CVE images built and maintained by Bitnami. Bitnami Secure Images are based on the cloud-optimized, security-hardened enterprise [OS Photon Linux](https://vmware.github.io/photon/). Why choose BSI images?

- Hardened secure images of popular open source software with Near-Zero Vulnerabilities
- Vulnerability Triage & Prioritization with VEX Statements, KEV and EPSS Scores
- Compliance focus with FIPS, STIG, and air-gap options, including secure bill of materials (SBOM)
- Software supply chain provenance attestation through in-toto
- First class support for the internet’s favorite Helm charts

Each image comes with valuable security metadata. You can view the metadata in [our public catalog here](https://app-catalog.vmware.com/bitnami/apps). Note: Some data is only available with [commercial subscriptions to BSI](https://bitnami.com/).

![Alt text](https://github.com/bitnami/containers/blob/main/BSI%20UI%201.png?raw=true "Application details")
![Alt text](https://github.com/bitnami/containers/blob/main/BSI%20UI%202.png?raw=true "Packaging report")

If you are looking for our previous generation of images based on Debian Linux, please see the [Bitnami Legacy registry](https://hub.docker.com/u/bitnamilegacy).

## Introduction

This chart bootstraps a [Tomcat](https://github.com/bitnami/containers/tree/main/bitnami/tomcat) deployment on a [Kubernetes](https://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

Tomcat implements several Java EE specifications including Java Servlet, JavaServer Pages, Java EL, and WebSocket, and provides a "pure Java" HTTP web server environment for Java code to run in.

## Before you begin

- Kubernetes 1.23+
- Helm 3.8.0+
- PV provisioner support in the underlying infrastructure
- ReadWriteMany volumes for deployment scaling

## Installing the Chart

First, log in to the OCI registry and create a secret with your registry credentials:

```console
helm registry login REGISTRY_NAME
kubectl create secret docker-registry SECRET_NAME -n NAMESPACE \
  --docker-server REGISTRY_NAME \
  --docker-username "USER" \
  --docker-password "TOKEN"
```

> **Note** Replace the placeholders in these commands (`REGISTRY_NAME`, `SECRET_NAME`, `NAMESPACE`, `USER`, and `TOKEN`) with your actual values.

Then install the chart with the release name `my-release`:

```console
helm install my-release oci://REGISTRY_NAME/REPOSITORY_NAME/tomcat --set "global.imagePullSecrets[0]=SECRET_NAME" -n NAMESPACE
```

> **Note** Replace the placeholders in the `helm install` command (`REGISTRY_NAME`, `REPOSITORY_NAME`, `SECRET_NAME`, and `NAMESPACE`) with your actual values.

These commands deploy Tomcat on the Kubernetes cluster in the default configuration. The [Parameters](#parameters) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Configuration and installation details

This section describes credentials, configuration, and other installation options.

### Gateway API

This chart provides support for exposing Apache Tomcat using the [Gateway API](https://gateway-api.sigs.k8s.io/) and its `HTTPRoute` resource. If you have a Gateway controller installed on your cluster, such as APISIX, Contour, Envoy Gateway, NGINX Gateway Fabric or Kong Ingress Controller you can utilize the Gateway controller to serve your application. To enable Gateway API integration, set `httpRoute.enabled` to `true`.
The Gateway to be used can be customized by setting the `httpRoute.parentRefs` parameter. By default, it will reference a Gateway named `gateway` in the same namespace as the release.

You can specify the list of hostnames to be mapped to the deployment using the `httpRoute.hostnames` parameter. Additionally, you can customize the rules used to route the traffic to the service by modifying the `httpRoute.matches` and `httpRoute.filters` parameters or adding new rules using the `httpRoute.extraRules` parameter.

### Ingress

This chart provides support for Ingress resources. If you have an ingress controller installed on your cluster, such as NGINX Ingress Controller or Contour you can utilize the ingress controller to serve your application. To enable Ingress integration, set `ingress.enabled` to `true`.

The most common scenario is to have one host name mapped to the deployment. In this case, the `ingress.hostname` property can be used to set the host name. The `ingress.tls` parameter can be used to add the TLS configuration for this host.

However, it is also possible to have more than one host. To facilitate this, the `ingress.extraHosts` parameter (if available) can be set with the host names specified as an array. The `ingress.extraTLS` parameter (if available) can also be used to add the TLS configuration for extra hosts.

> NOTE: For each host specified in the `ingress.extraHosts` parameter, it is necessary to set a name, path, and any annotations that the Ingress controller should know about. Not all annotations are supported by all Ingress controllers, but [this annotation reference document](https://github.com/kubernetes/ingress-nginx/blob/master/docs/user-guide/nginx-configuration/annotations.md) lists the annotations supported by many popular Ingress controllers.

Adding the TLS parameter (where available) will cause the chart to generate HTTPS URLs, and the application will be available on port 443. The actual TLS secrets do not have to be generated by this chart. However, if TLS is enabled, the Ingress record will not work until the TLS secret exists.

[Learn more about Ingress controllers](https://kubernetes.io/docs/concepts/services-networking/ingress-controllers/).

### Resource requests and limits

Bitnami charts allow setting resource requests and limits for all containers inside the chart deployment. These are inside the `resources` value (check parameter table). Setting requests is essential for production workloads and these should be adapted to your specific use case.

To make this process easier, the chart contains the `resourcesPreset` values, which automatically sets the `resources` section according to different presets. Check these presets in [the bitnami/common chart](https://github.com/bitnami/charts/blob/main/bitnami/common/templates/_resources.tpl#L15). However, in production workloads using `resourcesPreset` is discouraged as it may not fully adapt to your specific needs. Find more information on container resource management in the [official Kubernetes documentation](https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/).

### Update credentials

Bitnami charts configure credentials at first boot. Any further change in the secrets or credentials require manual intervention. Follow these instructions:

- Update the user password following [the upstream documentation](https://tomcat.apache.org/)
- Update the password secret with the new values (replace the SECRET_NAME, USER and PASSWORD placeholders)

```shell
kubectl create secret generic SECRET_NAME --from-literal=tomcat-username=USER --from-literal=tomcat-password=PASSWORD --dry-run -o yaml | kubectl apply -f -
```

### Prometheus metrics

This chart can be integrated with Prometheus by setting `metrics.enabled` to `true`. This will deploy a sidecar container with [jmx_exporter](https://github.com/prometheus/jmx_exporter) in all pods. It will have the necessary annotations to be automatically scraped by Prometheus.

#### Prometheus requirements

It is necessary to have a working installation of Prometheus or Prometheus Operator for the integration to work. Install the [Bitnami Prometheus helm chart](https://github.com/bitnami/charts/tree/main/bitnami/prometheus) or the [Bitnami Kube Prometheus helm chart](https://github.com/bitnami/charts/tree/main/bitnami/kube-prometheus) to easily have a working Prometheus in your cluster.

#### Integration with Prometheus Operator

The chart can deploy `PodMonitor` objects for integration with Prometheus Operator installations. To do so, set the value `metrics.podMonitor.enabled=true`. Ensure that the Prometheus Operator `CustomResourceDefinitions` are installed in the cluster or it will fail with the following error:

```text
no matches for kind "PodMonitor" in version "monitoring.coreos.com/v1"
```

Install the [Bitnami Kube Prometheus helm chart](https://github.com/bitnami/charts/tree/main/bitnami/kube-prometheus) for having the necessary CRDs and the Prometheus Operator.

### [Rolling vs Immutable tags](https://techdocs.broadcom.com/us/en/vmware-tanzu/bitnami-secure-images/bitnami-secure-images/services/bsi-doc/apps-tutorials-understand-rolling-tags-containers-index.html)

It is strongly recommended to use immutable tags in a production environment. This ensures your deployment does not change automatically if the same tag is updated with a different image.

Bitnami will release a new chart updating its containers if a new version of the main container, significant changes, or critical vulnerabilities exist.

### Use a different Tomcat version

To modify the application version used in this chart, specify a different version of the image using the `image.tag` parameter and/or a different repository using the `image.repository` parameter.

### Add extra environment variables

To add extra environment variables (useful for advanced operations like custom init scripts), use the `extraEnvVars` property.

```yaml
extraEnvVars:
  - name: LOG_LEVEL
    value: DEBUG
```

Alternatively, define a ConfigMap or a Secret with the environment variables. To do so, use the `extraEnvVarsCM` or the `extraEnvVarsSecret` values.

### Use Sidecars and Init Containers

If additional containers are needed in the same pod (such as additional metrics or logging exporters), they can be defined using the `sidecars` config parameter.

```yaml
sidecars:
- name: your-image-name
  image: your-image
  imagePullPolicy: Always
  ports:
  - name: portname
    containerPort: 1234
```

If these sidecars export extra ports, extra port definitions can be added using the `service.extraPorts` parameter (where available), as shown in the example below:

```yaml
service:
  extraPorts:
  - name: extraPort
    port: 11311
    targetPort: 11311
```

> NOTE: This Helm chart already includes sidecar containers for the Prometheus exporters (where applicable). These can be activated by adding the `--enable-metrics=true` parameter at deployment time. The `sidecars` parameter should therefore only be used for any extra sidecar containers.

If additional init containers are needed in the same pod, they can be defined using the `initContainers` parameter. Here is an example:

```yaml
initContainers:
  - name: your-image-name
    image: your-image
    imagePullPolicy: Always
    ports:
      - name: portname
        containerPort: 1234
```

Learn more about [sidecar containers](https://kubernetes.io/docs/concepts/workloads/pods/) and [init containers](https://kubernetes.io/docs/concepts/workloads/pods/init-containers/).

### Set Pod affinity

This chart allows you to set custom Pod affinity using the `affinity` parameter. Find more information about Pod's affinity in the [Kubernetes documentation](https://kubernetes.io/docs/concepts/configuration/assign-pod-node/#affinity-and-anti-affinity).

As an alternative, use one of the preset configurations for pod affinity, pod anti-affinity, and node affinity available at the [bitnami/common](https://github.com/bitnami/charts/tree/main/bitnami/common#affinities) chart. To do so, set the `podAffinityPreset`, `podAntiAffinityPreset`, or `nodeAffinityPreset` parameters.

### Backup and restore

To back up and restore Helm chart deployments on Kubernetes, you need to back up the persistent volumes from the source deployment and attach them to a new deployment using [Velero](https://velero.io/), a Kubernetes backup/restore tool. Find the instructions for using Velero in [this guide](https://techdocs.broadcom.com/us/en/vmware-tanzu/bitnami-secure-images/bitnami-secure-images/services/bsi-doc/apps-tutorials-backup-restore-deployments-velero-index.html).

### FIPS parameters

The FIPS parameters only have effect if you are using images from the [Bitnami Secure Images catalog](https://go-vmware.broadcom.com/contact-us).

For more information on this new support, please refer to the [FIPS Compliance section](https://techdocs.broadcom.com/us/en/vmware-tanzu/bitnami-secure-images/bitnami-secure-images/services/bsi-doc/security-frameworks-FIPS-compliance.html).

## Persistence

The [Bitnami Tomcat](https://github.com/bitnami/containers/tree/main/bitnami/tomcat) image stores the Tomcat data and configurations at the `/bitnami/tomcat` path of the container.

Persistent Volume Claims (PVCs) are used to keep the data across deployments. This is known to work in GCE, AWS, and minikube.

See the [Parameters](#parameters) section to configure the PVC or to disable persistence.

### Adjust permissions of persistent volume mountpoint

As the image run as non-root by default, it is necessary to adjust the ownership of the persistent volume so that the container can write data into it.

By default, the chart is configured to use Kubernetes Security Context to automatically change the ownership of the volume. However, this feature does not work in all Kubernetes distributions.
As an alternative, this chart supports using an init container to change the ownership of the volume before mounting it in the final destination.

You can enable this init container by setting `volumePermissions.enabled` to `true`.

## Parameters

### Global parameters

| Name                                                  | Description                                                                                                                                                                                                                                                                                                                                                         | Value        |
| ----------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------ |
| `global.imageRegistry`                                | Global Docker image registry                                                                                                                                                                                                                                                                                                                                        | `""`         |
| `global.imagePullSecrets`                             | Global Docker registry secret names as an array                                                                                                                                                                                                                                                                                                                     | `[]`         |
| `global.defaultStorageClass`                          | Global default StorageClass for Persistent Volume(s)                                                                                                                                                                                                                                                                                                                | `""`         |
| `global.storageClass`                                 | DEPRECATED: use global.defaultStorageClass instead                                                                                                                                                                                                                                                                                                                  | `""`         |
| `global.defaultFips`                                  | Default value for the FIPS configuration (allowed values: '', restricted, relaxed, off). Can be overridden by the 'fips' object                                                                                                                                                                                                                                     | `restricted` |
| `global.security.allowInsecureImages`                 | Allows skipping image verification                                                                                                                                                                                                                                                                                                                                  | `false`      |
| `global.compatibility.openshift.adaptSecurityContext` | Adapt the securityContext sections of the deployment to make them compatible with Openshift restricted-v2 SCC: remove runAsUser, runAsGroup and fsGroup and let the platform use their allowed default IDs. Possible values: auto (apply if the detected running cluster is Openshift), force (perform the adaptation always), disabled (do not perform adaptation) | `disabled`   |

### Common parameters

| Name                | Description                                                                                  | Value           |
| ------------------- | -------------------------------------------------------------------------------------------- | --------------- |
| `kubeVersion`       | Force target Kubernetes version (using Helm capabilities if not set)                         | `""`            |
| `nameOverride`      | String to partially override common.names.fullname template (will maintain the release name) | `""`            |
| `fullnameOverride`  | String to fully override common.names.fullname template                                      | `""`            |
| `commonLabels`      | Add labels to all the deployed resources                                                     | `{}`            |
| `commonAnnotations` | Add annotations to all the deployed resources                                                | `{}`            |
| `clusterDomain`     | Kubernetes Cluster Domain                                                                    | `cluster.local` |
| `extraDeploy`       | Array of extra objects to deploy with the release                                            | `[]`            |
| `usePasswordFiles`  | Mount credentials as files instead of using environment variables                            | `true`          |

### Tomcat parameters

| Name                           | Description                                                                                                                                                                          | Value                    |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------ |
| `image.registry`               | Tomcat image registry                                                                                                                                                                | `REGISTRY_NAME`          |
| `image.repository`             | Tomcat image repository                                                                                                                                                              | `REPOSITORY_NAME/tomcat` |
| `image.digest`                 | Tomcat image digest in the way sha256:aa.... Please note this parameter, if set, will override the tag                                                                               | `""`                     |
| `image.pullPolicy`             | Tomcat image pull policy                                                                                                                                                             | `IfNotPresent`           |
| `image.pullSecrets`            | Specify docker-registry secret names as an array                                                                                                                                     | `[]`                     |
| `image.debug`                  | Specify if debug logs should be enabled                                                                                                                                              | `false`                  |
| `automountServiceAccountToken` | Mount Service Account token in pod                                                                                                                                                   | `false`                  |
| `hostAliases`                  | Deployment pod host aliases                                                                                                                                                          | `[]`                     |
| `tomcatUsername`               | Tomcat admin user                                                                                                                                                                    | `user`                   |
| `tomcatPassword`               | Tomcat admin password                                                                                                                                                                | `""`                     |
| `existingSecret`               | Use existing secret for credentials details (`tomcatUsername` and `tomcatPassword` will be ignored and picked up from this secret)                                                   | `""`                     |
| `secretKeys.adminUsernameKey`  | Name of key in existing secret to use instead of default `tomcat-username` key to provide Tomcat admin username (overrides `tomcatUsername`). Only used when `existingSecret` is set | `""`                     |
| `secretKeys.adminPasswordKey`  | Name of key in existing secret to use instead of default `tomcat-password` key to provide Tomcat admin password (overrides `tomcatPassword`). Only used when `existingSecret` is set | `""`                     |
| `tomcatInstallDefaultWebapps`  | Install default webapps                                                                                                                                                              | `false`                  |
| `tomcatAllowRemoteManagement`  | Enable remote access to management interface                                                                                                                                         | `false`                  |
| `catalinaOpts`                 | Java runtime option used by tomcat JVM                                                                                                                                               | `""`                     |
| `command`                      | Override default container command (useful when using custom images)                                                                                                                 | `[]`                     |
| `args`                         | Override default container args (useful when using custom images)                                                                                                                    | `[]`                     |
| `extraEnvVars`                 | Extra environment variables to be set on Tomcat container                                                                                                                            | `[]`                     |
| `extraEnvVarsCM`               | Name of existing ConfigMap containing extra environment variables                                                                                                                    | `""`                     |
| `extraEnvVarsSecret`           | Name of existing Secret containing extra environment variables                                                                                                                       | `""`                     |

### Tomcat deployment parameters

| Name                                                | Description                                                                                                                                                                                                       | Value               |
| --------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------- |
| `replicaCount`                                      | Specify number of Tomcat replicas                                                                                                                                                                                 | `1`                 |
| `deployment.type`                                   | Use Deployment or StatefulSet                                                                                                                                                                                     | `deployment`        |
| `updateStrategy.type`                               | StrategyType                                                                                                                                                                                                      | `RollingUpdate`     |
| `containerPorts.http`                               | HTTP port to expose at container level                                                                                                                                                                            | `8080`              |
| `containerExtraPorts`                               | Extra ports to expose at container level                                                                                                                                                                          | `[]`                |
| `podSecurityContext.enabled`                        | Enable Tomcat pods' Security Context                                                                                                                                                                              | `true`              |
| `podSecurityContext.fsGroupChangePolicy`            | Set filesystem group change policy                                                                                                                                                                                | `Always`            |
| `podSecurityContext.sysctls`                        | Set kernel settings using the sysctl interface                                                                                                                                                                    | `[]`                |
| `podSecurityContext.supplementalGroups`             | Set filesystem extra groups                                                                                                                                                                                       | `[]`                |
| `podSecurityContext.fsGroup`                        | Set Tomcat pod's Security Context fsGroup                                                                                                                                                                         | `1001`              |
| `containerSecurityContext.enabled`                  | Enabled containers' Security Context                                                                                                                                                                              | `true`              |
| `containerSecurityContext.seLinuxOptions`           | Set SELinux options in container                                                                                                                                                                                  | `{}`                |
| `containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser                                                                                                                                                                        | `1001`              |
| `containerSecurityContext.runAsGroup`               | Set containers' Security Context runAsGroup                                                                                                                                                                       | `1001`              |
| `containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                                                                                                                                                                     | `true`              |
| `containerSecurityContext.privileged`               | Set container's Security Context privileged                                                                                                                                                                       | `false`             |
| `containerSecurityContext.readOnlyRootFilesystem`   | Set container's Security Context readOnlyRootFilesystem                                                                                                                                                           | `true`              |
| `containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation                                                                                                                                                         | `false`             |
| `containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                                                                                                                                                                | `["ALL"]`           |
| `containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                                                                                                                                                                  | `RuntimeDefault`    |
| `resourcesPreset`                                   | Set container resources according to one common preset (allowed values: none, nano, micro, small, medium, large, xlarge, 2xlarge). This is ignored if resources is set (resources is recommended for production). | `micro`             |
| `resources`                                         | Set container requests and limits for different resources like CPU or memory (essential for production workloads)                                                                                                 | `{}`                |
| `fips.openssl`                                      | Configure OpenSSL FIPS mode: '', 'restricted', 'relaxed', 'off'. If empty (""), 'global.defaultFips' would be used                                                                                                | `""`                |
| `fips.java`                                         | Configure Java FIPS mode: '', 'restricted', 'relaxed', 'off'. If empty (""), 'global.defaultFips' would be used                                                                                                   | `""`                |
| `livenessProbe.enabled`                             | Enable livenessProbe                                                                                                                                                                                              | `true`              |
| `livenessProbe.initialDelaySeconds`                 | Initial delay seconds for livenessProbe                                                                                                                                                                           | `120`               |
| `livenessProbe.periodSeconds`                       | Period seconds for livenessProbe                                                                                                                                                                                  | `10`                |
| `livenessProbe.timeoutSeconds`                      | Timeout seconds for livenessProbe                                                                                                                                                                                 | `5`                 |
| `livenessProbe.failureThreshold`                    | Failure threshold for livenessProbe                                                                                                                                                                               | `6`                 |
| `livenessProbe.successThreshold`                    | Success threshold for livenessProbe                                                                                                                                                                               | `1`                 |
| `readinessProbe.enabled`                            | Enable readinessProbe                                                                                                                                                                                             | `true`              |
| `readinessProbe.initialDelaySeconds`                | Initial delay seconds for readinessProbe                                                                                                                                                                          | `30`                |
| `readinessProbe.periodSeconds`                      | Period seconds for readinessProbe                                                                                                                                                                                 | `5`                 |
| `readinessProbe.timeoutSeconds`                     | Timeout seconds for readinessProbe                                                                                                                                                                                | `3`                 |
| `readinessProbe.failureThreshold`                   | Failure threshold for readinessProbe                                                                                                                                                                              | `3`                 |
| `readinessProbe.successThreshold`                   | Success threshold for readinessProbe                                                                                                                                                                              | `1`                 |
| `startupProbe.enabled`                              | Enable startupProbe                                                                                                                                                                                               | `false`             |
| `startupProbe.initialDelaySeconds`                  | Initial delay seconds for startupProbe                                                                                                                                                                            | `30`                |
| `startupProbe.periodSeconds`                        | Period seconds for startupProbe                                                                                                                                                                                   | `5`                 |
| `startupProbe.timeoutSeconds`                       | Timeout seconds for startupProbe                                                                                                                                                                                  | `3`                 |
| `startupProbe.failureThreshold`                     | Failure threshold for startupProbe                                                                                                                                                                                | `3`                 |
| `startupProbe.successThreshold`                     | Success threshold for startupProbe                                                                                                                                                                                | `1`                 |
| `customLivenessProbe`                               | Override default liveness probe                                                                                                                                                                                   | `{}`                |
| `customReadinessProbe`                              | Override default readiness probe                                                                                                                                                                                  | `{}`                |
| `customStartupProbe`                                | Override default startup probe                                                                                                                                                                                    | `{}`                |
| `podLabels`                                         | Extra labels for Tomcat pods                                                                                                                                                                                      | `{}`                |
| `podAnnotations`                                    | Annotations for Tomcat pods                                                                                                                                                                                       | `{}`                |
| `podAffinityPreset`                                 | Pod affinity preset. Ignored if `affinity` is set. Allowed values: `soft` or `hard`                                                                                                                               | `""`                |
| `podAntiAffinityPreset`                             | Pod anti-affinity preset. Ignored if `affinity` is set. Allowed values: `soft` or `hard`                                                                                                                          | `soft`              |
| `nodeAffinityPreset.type`                           | Node affinity preset type. Ignored if `affinity` is set. Allowed values: `soft` or `hard`                                                                                                                         | `""`                |
| `nodeAffinityPreset.key`                            | Node label key to match. Ignored if `affinity` is set.                                                                                                                                                            | `""`                |
| `nodeAffinityPreset.values`                         | Node label values to match. Ignored if `affinity` is set.                                                                                                                                                         | `[]`                |
| `affinity`                                          | Affinity for pod assignment. Evaluated as a template.                                                                                                                                                             | `{}`                |
| `nodeSelector`                                      | Node labels for pod assignment. Evaluated as a template.                                                                                                                                                          | `{}`                |
| `schedulerName`                                     | Alternative scheduler                                                                                                                                                                                             | `""`                |
| `runtimeClassName`                                  | Name of the runtime class to be used by pod(s)                                                                                                                                                                    | `""`                |
| `lifecycleHooks`                                    | Override default etcd container hooks                                                                                                                                                                             | `{}`                |
| `podManagementPolicy`                               | podManagementPolicy to manage scaling operation of pods (only in StatefulSet mode)                                                                                                                                | `""`                |
| `tolerations`                                       | Tolerations for pod assignment. Evaluated as a template.                                                                                                                                                          | `[]`                |
| `topologySpreadConstraints`                         | Topology Spread Constraints for pod assignment spread across your cluster among failure-domains. Evaluated as a template                                                                                          | `[]`                |
| `extraPodSpec`                                      | Optionally specify extra PodSpec                                                                                                                                                                                  | `{}`                |
| `extraVolumes`                                      | Optionally specify extra list of additional volumes for Tomcat pods in Deployment                                                                                                                                 | `[]`                |
| `extraVolumeClaimTemplates`                         | Optionally specify extra list of additional volume claim templates for Tomcat pods in StatefulSet                                                                                                                 | `[]`                |
| `extraVolumeMounts`                                 | Optionally specify extra list of additional volumeMounts for Tomcat container(s)                                                                                                                                  | `[]`                |
| `initContainers`                                    | Add init containers to the Tomcat pods.                                                                                                                                                                           | `[]`                |
| `pdb.create`                                        | Enable/disable a Pod Disruption Budget creation                                                                                                                                                                   | `true`              |
| `pdb.minAvailable`                                  | Minimum number/percentage of pods that should remain scheduled                                                                                                                                                    | `""`                |
| `pdb.maxUnavailable`                                | Maximum number/percentage of pods that may be made unavailable. Defaults to `1` if both `pdb.minAvailable` and `pdb.maxUnavailable` are empty.                                                                    | `""`                |
| `sidecars`                                          | Add sidecars to the Tomcat pods.                                                                                                                                                                                  | `[]`                |
| `persistence.enabled`                               | Enable persistence                                                                                                                                                                                                | `true`              |
| `persistence.storageClass`                          | PVC Storage Class for Tomcat volume                                                                                                                                                                               | `""`                |
| `persistence.annotations`                           | Persistent Volume Claim annotations                                                                                                                                                                               | `{}`                |
| `persistence.labels`                                | Persistent Volume Claim labels                                                                                                                                                                                    | `{}`                |
| `persistence.accessModes`                           | PVC Access Modes for Tomcat volume                                                                                                                                                                                | `["ReadWriteOnce"]` |
| `persistence.size`                                  | PVC Storage Request for Tomcat volume                                                                                                                                                                             | `8Gi`               |
| `persistence.existingClaim`                         | An Existing PVC name for Tomcat volume                                                                                                                                                                            | `""`                |
| `persistence.selectorLabels`                        | Selector labels to use in volume claim template in statefulset                                                                                                                                                    | `{}`                |
| `networkPolicy.enabled`                             | Specifies whether a NetworkPolicy should be created                                                                                                                                                               | `true`              |
| `networkPolicy.allowExternal`                       | Don't require server label for connections                                                                                                                                                                        | `true`              |
| `networkPolicy.allowExternalEgress`                 | Allow the pod to access any range of port and all destinations.                                                                                                                                                   | `true`              |
| `networkPolicy.extraIngress`                        | Add extra ingress rules to the NetworkPolicy                                                                                                                                                                      | `[]`                |
| `networkPolicy.extraEgress`                         | Add extra ingress rules to the NetworkPolicy                                                                                                                                                                      | `[]`                |
| `networkPolicy.ingressNSMatchLabels`                | Labels to match to allow traffic from other namespaces                                                                                                                                                            | `{}`                |
| `networkPolicy.ingressNSPodMatchLabels`             | Pod labels to match to allow traffic from other namespaces                                                                                                                                                        | `{}`                |
| `serviceAccount.create`                             | Enable creation of ServiceAccount for Tomcat pod                                                                                                                                                                  | `true`              |
| `serviceAccount.name`                               | The name of the ServiceAccount to use.                                                                                                                                                                            | `""`                |
| `serviceAccount.automountServiceAccountToken`       | Allows auto mount of ServiceAccountToken on the serviceAccount created                                                                                                                                            | `false`             |
| `serviceAccount.annotations`                        | Additional custom annotations for the ServiceAccount                                                                                                                                                              | `{}`                |

### Traffic Exposure parameters

| Name                               | Description                                                                                                                      | Value                    |
| ---------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- | ------------------------ |
| `service.type`                     | Kubernetes Service type                                                                                                          | `LoadBalancer`           |
| `service.ports.http`               | Service HTTP port                                                                                                                | `80`                     |
| `service.nodePorts.http`           | Kubernetes http node port                                                                                                        | `""`                     |
| `service.extraPorts`               | Extra ports to expose (normally used with the `sidecar` value)                                                                   | `[]`                     |
| `service.loadBalancerIP`           | Port Use serviceLoadBalancerIP to request a specific static IP, otherwise leave blank                                            | `""`                     |
| `service.clusterIP`                | Service Cluster IP                                                                                                               | `""`                     |
| `service.loadBalancerSourceRanges` | Service Load Balancer sources                                                                                                    | `[]`                     |
| `service.externalTrafficPolicy`    | Enable client source IP preservation                                                                                             | `Cluster`                |
| `service.annotations`              | Annotations for Tomcat service                                                                                                   | `{}`                     |
| `service.sessionAffinity`          | Session Affinity for Kubernetes service, can be "None" or "ClientIP"                                                             | `None`                   |
| `service.sessionAffinityConfig`    | Additional settings for the sessionAffinity. Ignored if `service.sessionAffinity` is `None`                                      | `{}`                     |
| `service.headless.annotations`     | Annotations for the headless service.                                                                                            | `{}`                     |
| `httpRoute.enabled`                | Enable HTTPRoute generation for Tomcat                                                                                           | `false`                  |
| `httpRoute.annotations`            | Additional annotations for the HTTPRoute resource                                                                                | `{}`                     |
| `httpRoute.labels`                 | Additional labels for the HTTPRoute resource                                                                                     | `{}`                     |
| `httpRoute.parentRefs`             | Gateways the HTTPRoute is attached to. If unspecified, it'll be attached to Gateway named 'gateway' in the same namespace.       | `[]`                     |
| `httpRoute.hostnames`              | List of hostnames matching HTTP header                                                                                           | `[]`                     |
| `httpRoute.matches`                | List of match rules applied to the HTTPRoute for the default svc backend reference                                               | `[]`                     |
| `httpRoute.filters`                | List of filter rules applied to the HTTPRoute for the default svc backend reference                                              | `[]`                     |
| `httpRoute.extraRules`             | List of extra rules applied to the HTTPRoute                                                                                     | `[]`                     |
| `ingress.enabled`                  | Enable ingress controller resource                                                                                               | `false`                  |
| `ingress.certManager`              | Add the corresponding annotations for cert-manager integration                                                                   | `false`                  |
| `ingress.hostname`                 | Default host for the ingress resource                                                                                            | `tomcat.local`           |
| `ingress.annotations`              | Additional annotations for the Ingress resource. To enable certificate autogeneration, place here your cert-manager annotations. | `{}`                     |
| `ingress.tls`                      | Enable TLS configuration for the hostname defined at `ingress.hostname` parameter                                                | `false`                  |
| `ingress.extraHosts`               | The list of additional hostnames to be covered with this ingress record.                                                         | `[]`                     |
| `ingress.extraTls`                 | The tls configuration for additional hostnames to be covered with this ingress record.                                           | `[]`                     |
| `ingress.extraPaths`               | Any additional arbitrary paths that may need to be added to the ingress under the main host.                                     | `[]`                     |
| `ingress.selfSigned`               | Create a TLS secret for this ingress record using self-signed certificates generated by Helm                                     | `false`                  |
| `ingress.ingressClassName`         | IngressClass that will be be used to implement the Ingress (Kubernetes 1.18+)                                                    | `""`                     |
| `ingress.secrets`                  | If you're providing your own certificates, please use this to add the certificates as secrets                                    | `[]`                     |
| `ingress.extraRules`               | Additional rules to be covered with this ingress record                                                                          | `[]`                     |
| `ingress.apiVersion`               | Force Ingress API version (automatically detected if not set)                                                                    | `""`                     |
| `ingress.path`                     | Ingress path                                                                                                                     | `/`                      |
| `ingress.pathType`                 | Ingress path type                                                                                                                | `ImplementationSpecific` |

### Volume Permissions parameters

| Name                                  | Description                                                                                                                                                                                                                                           | Value                      |
| ------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------- |
| `volumePermissions.enabled`           | Enable init container that changes volume permissions in the data directory                                                                                                                                                                           | `false`                    |
| `volumePermissions.image.registry`    | Init container volume-permissions image registry                                                                                                                                                                                                      | `REGISTRY_NAME`            |
| `volumePermissions.image.repository`  | Init container volume-permissions image repository                                                                                                                                                                                                    | `REPOSITORY_NAME/os-shell` |
| `volumePermissions.image.digest`      | Init container volume-permissions image digest in the way sha256:aa.... Please note this parameter, if set, will override the tag                                                                                                                     | `""`                       |
| `volumePermissions.image.pullPolicy`  | Init container volume-permissions image pull policy                                                                                                                                                                                                   | `IfNotPresent`             |
| `volumePermissions.image.pullSecrets` | Specify docker-registry secret names as an array                                                                                                                                                                                                      | `[]`                       |
| `volumePermissions.resourcesPreset`   | Set container resources according to one common preset (allowed values: none, nano, micro, small, medium, large, xlarge, 2xlarge). This is ignored if volumePermissions.resources is set (volumePermissions.resources is recommended for production). | `none`                     |
| `volumePermissions.resources`         | Set container requests and limits for different resources like CPU or memory (essential for production workloads)                                                                                                                                     | `{}`                       |
| `volumePermissions.fips.openssl`      | Configure OpenSSL FIPS mode: '', 'restricted', 'relaxed', 'off'. If empty (""), 'global.defaultFips' would be used                                                                                                                                    | `""`                       |

### Metrics parameters

| Name                                                            | Description                                                                                                                                                                                                                               | Value                                                                                                                                                                                                                                                                                                  |
| --------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `metrics.jmx.enabled`                                           | Whether or not to expose JMX metrics to Prometheus                                                                                                                                                                                        | `false`                                                                                                                                                                                                                                                                                                |
| `metrics.jmx.catalinaOpts`                                      | custom option used to enabled JMX on tomcat jvm evaluated as template                                                                                                                                                                     | `-Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=5555 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.local.only=true -Dcom.sun.management.jmxremote.host=127.0.0.1 -Djava.rmi.server.hostname=127.0.0.1` |
| `metrics.jmx.image.registry`                                    | JMX exporter image registry                                                                                                                                                                                                               | `REGISTRY_NAME`                                                                                                                                                                                                                                                                                        |
| `metrics.jmx.image.repository`                                  | JMX exporter image repository                                                                                                                                                                                                             | `REPOSITORY_NAME/jmx-exporter`                                                                                                                                                                                                                                                                         |
| `metrics.jmx.image.digest`                                      | JMX exporter image digest in the way sha256:aa.... Please note this parameter, if set, will override the tag                                                                                                                              | `""`                                                                                                                                                                                                                                                                                                   |
| `metrics.jmx.image.pullPolicy`                                  | JMX exporter image pull policy                                                                                                                                                                                                            | `IfNotPresent`                                                                                                                                                                                                                                                                                         |
| `metrics.jmx.image.pullSecrets`                                 | Specify docker-registry secret names as an array                                                                                                                                                                                          | `[]`                                                                                                                                                                                                                                                                                                   |
| `metrics.jmx.config`                                            | Configuration file for JMX exporter                                                                                                                                                                                                       | `""`                                                                                                                                                                                                                                                                                                   |
| `metrics.jmx.containerSecurityContext.enabled`                  | Enabled containers' Security Context                                                                                                                                                                                                      | `true`                                                                                                                                                                                                                                                                                                 |
| `metrics.jmx.containerSecurityContext.seLinuxOptions`           | Set SELinux options in container                                                                                                                                                                                                          | `{}`                                                                                                                                                                                                                                                                                                   |
| `metrics.jmx.containerSecurityContext.runAsUser`                | Set containers' Security Context runAsUser                                                                                                                                                                                                | `1001`                                                                                                                                                                                                                                                                                                 |
| `metrics.jmx.containerSecurityContext.runAsGroup`               | Set containers' Security Context runAsGroup                                                                                                                                                                                               | `1001`                                                                                                                                                                                                                                                                                                 |
| `metrics.jmx.containerSecurityContext.runAsNonRoot`             | Set container's Security Context runAsNonRoot                                                                                                                                                                                             | `true`                                                                                                                                                                                                                                                                                                 |
| `metrics.jmx.containerSecurityContext.privileged`               | Set container's Security Context privileged                                                                                                                                                                                               | `false`                                                                                                                                                                                                                                                                                                |
| `metrics.jmx.containerSecurityContext.readOnlyRootFilesystem`   | Set container's Security Context readOnlyRootFilesystem                                                                                                                                                                                   | `true`                                                                                                                                                                                                                                                                                                 |
| `metrics.jmx.containerSecurityContext.allowPrivilegeEscalation` | Set container's Security Context allowPrivilegeEscalation                                                                                                                                                                                 | `false`                                                                                                                                                                                                                                                                                                |
| `metrics.jmx.containerSecurityContext.capabilities.drop`        | List of capabilities to be dropped                                                                                                                                                                                                        | `["ALL"]`                                                                                                                                                                                                                                                                                              |
| `metrics.jmx.containerSecurityContext.seccompProfile.type`      | Set container's Security Context seccomp profile                                                                                                                                                                                          | `RuntimeDefault`                                                                                                                                                                                                                                                                                       |
| `metrics.jmx.resourcesPreset`                                   | Set container resources according to one common preset (allowed values: none, nano, micro, small, medium, large, xlarge, 2xlarge). This is ignored if metrics.jmx.resources is set (metrics.jmx.resources is recommended for production). | `none`                                                                                                                                                                                                                                                                                                 |
| `metrics.jmx.resources`                                         | Set container requests and limits for different resources like CPU or memory (essential for production workloads)                                                                                                                         | `{}`                                                                                                                                                                                                                                                                                                   |
| `metrics.jmx.fips.openssl`                                      | Configure OpenSSL FIPS mode: '', 'restricted', 'relaxed', 'off'. If empty (""), 'global.defaultFips' would be used                                                                                                                        | `""`                                                                                                                                                                                                                                                                                                   |
| `metrics.jmx.fips.java`                                         | Configure Java FIPS mode: '', 'restricted', 'relaxed', 'off'. If empty (""), 'global.defaultFips' would be used                                                                                                                           | `""`                                                                                                                                                                                                                                                                                                   |
| `metrics.jmx.ports.metrics`                                     | JMX Exporter container metrics ports                                                                                                                                                                                                      | `5556`                                                                                                                                                                                                                                                                                                 |
| `metrics.jmx.existingConfigmap`                                 | Name of existing ConfigMap with JMX exporter configuration                                                                                                                                                                                | `""`                                                                                                                                                                                                                                                                                                   |
| `metrics.podMonitor.podTargetLabels`                            | Used to keep given pod's labels in target                                                                                                                                                                                                 | `[]`                                                                                                                                                                                                                                                                                                   |
| `metrics.podMonitor.enabled`                                    | Create PodMonitor Resource for scraping metrics using PrometheusOperator                                                                                                                                                                  | `false`                                                                                                                                                                                                                                                                                                |
| `metrics.podMonitor.namespace`                                  | Optional namespace in which Prometheus is running                                                                                                                                                                                         | `""`                                                                                                                                                                                                                                                                                                   |
| `metrics.podMonitor.interval`                                   | Specify the interval at which metrics should be scraped                                                                                                                                                                                   | `30s`                                                                                                                                                                                                                                                                                                  |
| `metrics.podMonitor.scrapeTimeout`                              | Specify the timeout after which the scrape is ended                                                                                                                                                                                       | `30s`                                                                                                                                                                                                                                                                                                  |
| `metrics.podMonitor.additionalLabels`                           | Additional labels that can be used so PodMonitors will be discovered by Prometheus                                                                                                                                                        | `{}`                                                                                                                                                                                                                                                                                                   |
| `metrics.podMonitor.scheme`                                     | Scheme to use for scraping                                                                                                                                                                                                                | `http`                                                                                                                                                                                                                                                                                                 |
| `metrics.podMonitor.tlsConfig`                                  | TLS configuration used for scrape endpoints used by Prometheus                                                                                                                                                                            | `{}`                                                                                                                                                                                                                                                                                                   |
| `metrics.podMonitor.relabelings`                                | Prometheus relabeling rules                                                                                                                                                                                                               | `[]`                                                                                                                                                                                                                                                                                                   |
| `metrics.prometheusRule.enabled`                                | Set this to true to create prometheusRules for Prometheus operator                                                                                                                                                                        | `false`                                                                                                                                                                                                                                                                                                |
| `metrics.prometheusRule.additionalLabels`                       | Additional labels that can be used so prometheusRules will be discovered by Prometheus                                                                                                                                                    | `{}`                                                                                                                                                                                                                                                                                                   |
| `metrics.prometheusRule.namespace`                              | namespace where prometheusRules resource should be created                                                                                                                                                                                | `""`                                                                                                                                                                                                                                                                                                   |
| `metrics.prometheusRule.rules`                                  | Create specified [Rules](https://prometheus.io/docs/prometheus/latest/configuration/alerting_rules/)                                                                                                                                      | `[]`                                                                                                                                                                                                                                                                                                   |

The above parameters map to the env variables defined in [bitnami/tomcat](https://github.com/bitnami/containers/tree/main/bitnami/tomcat). For more information please refer to the [bitnami/tomcat](https://github.com/bitnami/containers/tree/main/bitnami/tomcat) image documentation.

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`. For example,

```console
helm install my-release \
  --set tomcatUsername=manager,tomcatPassword=password oci://REGISTRY_NAME/REPOSITORY_NAME/tomcat
```

> Note: You need to substitute the placeholders `REGISTRY_NAME` and `REPOSITORY_NAME` with a reference to your Helm chart registry and repository. For example, in the case of Bitnami, you need to use `REGISTRY_NAME=registry-1.docker.io` and `REPOSITORY_NAME=bitnamicharts`.

The above command sets the Tomcat management username and password to `manager` and `password` respectively.

> NOTE: Once this chart is deployed, it is not possible to change the application's access credentials, such as usernames or passwords, using Helm. To change these application credentials after deployment, delete any persistent volumes (PVs) used by the chart and re-deploy it, or use the application's built-in administrative tools if available.

Alternatively, a YAML file that specifies the values for the parameters can be provided while installing the chart. For example,

```console
helm install my-release -f values.yaml oci://REGISTRY_NAME/REPOSITORY_NAME/tomcat
```

> Note: You need to substitute the placeholders `REGISTRY_NAME` and `REPOSITORY_NAME` with a reference to your Helm chart registry and repository. For example, in the case of Bitnami, you need to use `REGISTRY_NAME=registry-1.docker.io` and `REPOSITORY_NAME=bitnamicharts`.
> **Tip**: You can use the default [values.yaml](https://github.com/bitnami/charts/tree/main/bitnami/tomcat/values.yaml)

## Troubleshooting

Find more information about how to deal with common errors related to Bitnami's Helm charts in [this troubleshooting guide](https://docs.bitnami.com/general/how-to/troubleshoot-helm-chart-issues).

## Upgrading

The following subsections describe notable changes when upgrading.

### To 11.4.0

This version introduces image verification for security purposes. To disable it, set `global.security.allowInsecureImages` to `true`. More details at [GitHub issue](https://github.com/bitnami/charts/issues/30850).

### To 11.0.0

This major bump changes the following security defaults:

- `runAsGroup` is changed from `0` to `1001`
- `readOnlyRootFilesystem` is set to `true`
- `resourcesPreset` is changed from `none` to the minimum size working in our test suites (NOTE: `resourcesPreset` is not meant for production usage, but `resources` adapted to your use case).
- `global.compatibility.openshift.adaptSecurityContext` is changed from `disabled` to `auto`.
- The `networkPolicy` section has been normalized amongst all Bitnami charts. Compared to the previous approach, the values section has been simplified (check the Parameters section) and now it set to `enabled=true` by default. Egress traffic is allowed by default and ingress traffic is allowed by all pods but only to the ports set in `containerPorts`.

This could potentially break any customization or init scripts used in your deployment. If this is the case, change the default values to the previous ones.

### To 10.0.0

Some of the chart values were changed to adapt to the latest Bitnami standards. More specifically:

- `containerPort` was changed to `containerPorts.http`
- `service.port` was changed to `service.ports.http`

No issues should be expected when upgrading.

### To 8.0.0

- Chart labels were adapted to follow the [Helm charts standard labels](https://helm.sh/docs/chart_best_practices/labels/#standard-labels).
- Ingress configuration was also adapted to follow the Helm charts best practices.
- This version also introduces `bitnami/common`, a [library chart](https://helm.sh/docs/topics/library_charts/#helm) as a dependency. More documentation about this new utility could be found [here](https://github.com/bitnami/charts/tree/main/bitnami/common#bitnami-common-library-chart). Please, make sure that you have updated the chart dependencies before executing any upgrade.

Consequences:

- Backwards compatibility is not guaranteed. However, you can easily workaround this issue by removing Tomcat deployment before upgrading (the following example assumes that the release name is `tomcat`):

```console
export TOMCAT_PASSWORD=$(kubectl get secret --namespace default tomcat -o jsonpath="{.data.tomcat-password}" | base64 -d)
kubectl delete deployments.apps tomcat
helm upgrade tomcat oci://REGISTRY_NAME/REPOSITORY_NAME/tomcat --set tomcatPassword=$TOMCAT_PASSWORD
```

> Note: You need to substitute the placeholders `REGISTRY_NAME` and `REPOSITORY_NAME` with a reference to your Helm chart registry and repository. For example, in the case of Bitnami, you need to use `REGISTRY_NAME=registry-1.docker.io` and `REPOSITORY_NAME=bitnamicharts`.

### To 7.0.0

[On November 13, 2020, Helm v2 support formally ended](https://github.com/helm/charts#status-of-the-project). This major version is the result of the required changes applied to the Helm Chart to be able to incorporate the different features added in Helm v3 and to be consistent with the Helm project itself regarding the Helm v2 EOL.

### To 5.0.0

This release updates the Bitnami Tomcat container to `9.0.26-debian-9-r0`, which is based on Bash instead of Node.js.

### To 2.1.0

Tomcat container was moved to a non-root approach. There shouldn't be any issue when upgrading since the corresponding `securityContext` is enabled by default. Both the container image and the chart can be upgraded by running the command below:

```console
helm upgrade my-release oci://REGISTRY_NAME/REPOSITORY_NAME/tomcat
```

> Note: You need to substitute the placeholders `REGISTRY_NAME` and `REPOSITORY_NAME` with a reference to your Helm chart registry and repository. For example, in the case of Bitnami, you need to use `REGISTRY_NAME=registry-1.docker.io` and `REPOSITORY_NAME=bitnamicharts`.

If you use a previous container image (previous to **8.5.35-r26**) disable the `securityContext` by running the command below:

```console
helm upgrade my-release oci://REGISTRY_NAME/REPOSITORY_NAME/tomcat --set securityContext.enabled=false,image.tag=XXX
```

> Note: You need to substitute the placeholders `REGISTRY_NAME` and `REPOSITORY_NAME` with a reference to your Helm chart registry and repository. For example, in the case of Bitnami, you need to use `REGISTRY_NAME=registry-1.docker.io` and `REPOSITORY_NAME=bitnamicharts`.

### To 1.0.0

Backwards compatibility is not guaranteed unless you modify the labels used on the chart's deployments.
Use the workaround below to upgrade from versions previous to 1.0.0. The following example assumes that the release name is tomcat:

```console
kubectl patch deployment tomcat --type=json -p='[{"op": "remove", "path": "/spec/selector/matchLabels/chart"}]'
```

## License

Copyright &copy; 2025 Broadcom. The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

<http://www.apache.org/licenses/LICENSE-2.0>

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
