{{- define "feature.nodeLogs.module" }}
declare "node_logs" {
  argument "logs_destinations" {
    comment = "Must be a list of log destinations where collected logs should be forwarded to"
  }

  loki.relabel "journal" {
    {{- if len .Values.journal.units }}
    rule {
      action = "keep"
      source_labels = ["__journal__systemd_unit"]
      regex = "{{ join "|" .Values.journal.units }}"
    }
    {{- end }}

    rule {
      action = "replace"
      source_labels = ["__journal__systemd_unit"]
      replacement = "$1"
      target_label = "unit"
    }

    // the service_name label will be set automatically in loki if not set, and the unit label
    // will not allow service_name to be set automatically.
    rule {
      action = "replace"
      source_labels = ["__journal__systemd_unit"]
      replacement = "$1"
      target_label = "service_name"
    }

  {{- /* Extract journal fields needed for journalLabels */}}
  {{- range $label, $field := .Values.journalLabels }}
    rule {
      action = "replace"
      source_labels = ["__journal__{{ $field }}"]
      replacement = "$1"
      target_label = {{ $label | quote }}
    }
  {{- end }}

  {{- /* Extract journal fields needed for structuredMetadata (if not already extracted by journalLabels) */}}
  {{- range $key, $field := .Values.structuredMetadata }}
    {{- if not (hasKey $.Values.journalLabels $field) }}
    rule {
      action = "replace"
      source_labels = ["__journal__{{ $field }}"]
      replacement = "$1"
      target_label = {{ $field | quote }}
    }
    {{- end }}
  {{- end }}
  {{- if .Values.extraDiscoveryRules }}
  {{ .Values.extraDiscoveryRules | indent 2 }}
  {{- end }}

    forward_to = [] // No forward_to is used in this component, the defined rules are used in the loki.source.journal component
  } // loki.relabel "journal"

  loki.source.journal "worker" {
    path = {{ .Values.journal.path | quote }}
    format_as_json = {{ .Values.journal.formatAsJson }}
    max_age = {{ .Values.journal.maxAge | quote }}
    relabel_rules = loki.relabel.journal.rules
    labels = {
      job = {{ .Values.journal.jobLabel | quote }},
      instance = sys.env("HOSTNAME"),
    }
    forward_to = [loki.process.journal_logs.receiver]
  } // loki.source.journal "worker"

  loki.process "journal_logs" {
    stage.static_labels {
      values = {
        // add a static source label to the logs so they can be differentiated / restricted if necessary
        "source" = "journal",
        // default level to unknown
        level = "UNKNOWN",
      }
    }

    // Attempt to determine the log level, most k8s workers are either in logfmt or klog formats
    // check to see if the log line matches the klog format (https://github.com/kubernetes/klog)
    stage.match {
      // unescaped regex: ([IWED][0-9]{4}\s+[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]+)
      selector = "{level=\"UNKNOWN\"} |~ \"([IWED][0-9]{4}\\\\s+[0-9]{2}:[0-9]{2}:[0-9]{2}\\\\.[0-9]+)\""

      // extract log level, klog uses a single letter code for the level followed by the month and day i.e. I0119
      stage.regex {
        expression = "((?P<level>[A-Z])[0-9])"
      }

      // if the extracted level is I set INFO
      stage.replace {
        source = "level"
        expression = "(I)"
        replace = "INFO"
      }

      // if the extracted level is W set WARN
      stage.replace {
        source = "level"
        expression = "(W)"
        replace = "WARN"
      }
      // standardize on WARN
      stage.replace {
        source = "level"
        expression = "(warning)"
        replace = "WARN"
      }

      // if the extracted level is E set ERROR
      stage.replace {
        source = "level"
        expression = "(E)"
        replace = "ERROR"
      }

      // if the extracted level is I set INFO
      stage.replace {
        source = "level"
        expression = "(D)"
        replace = "DEBUG"
      }

      // set the extracted level to be a label
      stage.labels {
        values = {
          level = "",
        }
      }
    }

    // if the level is still unknown, do one last attempt at detecting it based on common levels
    stage.match {
      selector = "{level=\"UNKNOWN\"}"

      // unescaped regex: (?i)(?:"(?:level|loglevel|levelname|lvl|levelText|SeverityText)":\s*"|\s*(?:level|loglevel|levelText|lvl)="?|\s+\[?)(?P<level>(DEBUG?|DBG|INFO?(RMATION)?|WA?RN(ING)?|ERR(OR)?|CRI?T(ICAL)?|FATAL|FTL|NOTICE|TRACE|TRC|PANIC|PNC|ALERT|EMERGENCY))("|\s+|-|\s*\])
      stage.regex {
        expression = "(?i)(?:\"(?:level|loglevel|levelname|lvl|levelText|SeverityText)\":\\s*\"|\\s*(?:level|loglevel|levelText|lvl)=\"?|\\s+\\[?)(?P<level>(DEBUG?|DBG|INFO?(RMATION)?|WA?RN(ING)?|ERR(OR)?|CRI?T(ICAL)?|FATAL|FTL|NOTICE|TRACE|TRC|PANIC|PNC|ALERT|EMERGENCY))(\"|\\s+|-|\\s*\\])"
      }

      // set the extracted level to be a label
      stage.labels {
        values = {
          level = "",
        }
      }
    }

    // Standardize on upper-case
    stage.template {
      source   = "level"
      template = "{{ "{{ ToUpper .Value }}"}}"
    }

    {{- /* the stage.structured_metadata block needs to be conditionalized because the support for enabling structured metadata can be disabled */ -}}
    {{- /* through the loki limits_conifg on a per-tenant basis, even if there are no values defined or there are values defined but it is disabled */ -}}
    {{- /* in Loki, the write will fail. */ -}}
    {{- if gt (len (keys .Values.structuredMetadata)) 0 }}
    // set the structured metadata values
    stage.structured_metadata {
      values = {
        {{- range $key, $value := .Values.structuredMetadata }}
        {{ $key | quote }} = {{ if $value }}{{ $value | quote }}{{ else }}{{ $key | quote }}{{ end }},
        {{- end }}
      }
    }
    {{- end }}

    {{- if .Values.extraLogProcessingStages }}
    {{ tpl .Values.extraLogProcessingStages . | indent 4 }}
    {{ end }}

    forward_to = argument.logs_destinations.value
  } // loki.process "journal_logs"
} // declare "node_logs"
{{- end -}}
